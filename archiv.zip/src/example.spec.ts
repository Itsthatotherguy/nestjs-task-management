// feature
class FriendsList {
    friends = [];

    addFriend(name) {
        this.friends.push(name);
    }
}

// tests
describe('FriendsList', () => {
    it('initialises friends list', () => {
        const friendsList = new FriendsList();

        expect(friendsList.friends.length).toEqual(0);
    });

    it('adds a friend to the list', () => {
        const friendsList = new FriendsList();

        friendsList.addFriend('Ariel');
        expect(friendsList.friends.length).toEqual(1);
    });
});
